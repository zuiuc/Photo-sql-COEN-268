This is the homework 3 photo notes for COEN 268 created by Qi Zhao.
The target sdk is 22. No special library or implementation needed.